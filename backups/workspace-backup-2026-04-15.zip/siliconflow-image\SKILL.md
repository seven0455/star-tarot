---
name: siliconflow-image
description: Generate images using SiliconFlow (siliconflow.cn) Kolors API. Use when needing to create images from text prompts. Supports Chinese prompts, portrait/landscape formats, and direct PNG download. Triggers on: image generation, AI art creation, avatar generation, text-to-image, picture creation.
---

# SiliconFlow Image Generation

## Quick Start

```powershell
# 1. Call API
$body = @{
    model = "Kwai-Kolors/Kolors"
    prompt = "your prompt here"
    image_size = "1024x1792"  # portrait
} | ConvertTo-Json

$response = Invoke-RestMethod -Uri "https://api.siliconflow.cn/v1/images/generations" `
    -Method POST `
    -Headers @{ "Authorization" = "Bearer $apiKey"; "Content-Type" = "application/json" } `
    -Body $body

# 2. Download immediately (URLs expire!)
$webClient = New-Object System.Net.WebClient
$webClient.Headers.Add("User-Agent", "Mozilla/5.0")
$webClient.DownloadFile($response.data[0].url, "output.png")
$webClient.Dispose()
```

## API Details

- **Endpoint**: `https://api.siliconflow.cn/v1/images/generations`
- **Model**: `Kwai-Kolors/Kolors` (best for Chinese prompts)
- **Auth**: Bearer token in Authorization header

## Available Sizes

| Size | Dimensions | Use Case |
|------|------------|----------|
| 1024x1792 | 9:16 | Portrait/phone |
| 1024x1024 | 1:1 | Square |
| 1536x1024 | 3:2 | Landscape |
| 1024x1536 | 2:3 | Portrait |
| 1792x1024 | 16:9 | Wide |

## Prompt Tips

- Use English or Chinese prompts (Kolors understands both)
- Be specific: subject, clothing, setting, style
- Add quality tags: "high quality", "detailed", "masterpiece"

## Example Prompts

**Anime girl avatar**:
```
A cute anime girl with big sparkling eyes, wearing a cozy orange hoodie, sitting at a computer, blue simple background, portrait format, high quality illustration style
```

**Cartoon panda**:
```
A cute cartoon panda bear wearing an orange hoodie with headphones, sitting at a computer working, blue simple background, portrait format, high quality illustration style
```

## Troubleshooting

- **"Model does not exist"**: Use exact model name `Kwai-Kolors/Kolors`
- **URL expired**: Download immediately after getting response
- **403/400 errors**: URL has expired, regenerate image
