# SiliconFlow Image Generator
# Usage: .\generate-image.ps1 -Prompt "your prompt" -OutputFile "output.png" [-ApiKey "sk-..."]

param(
    [Parameter(Mandatory=$true)]
    [string]$Prompt,
    
    [Parameter(Mandatory=$true)]
    [string]$OutputFile,
    
    [string]$ApiKey = $env:SILICONFLOW_API_KEY,
    
    [string]$Model = "Kwai-Kolors/Kolors",
    
    [string]$Size = "1024x1792"
)

if (-not $ApiKey) {
    Write-Error "API key required. Set SILICONFLOW_API_KEY env var or pass -ApiKey"
    exit 1
}

$body = @{
    model = $Model
    prompt = $Prompt
    image_size = $Size
} | ConvertTo-Json

Write-Host "Generating image..."
$response = Invoke-RestMethod -Uri "https://api.siliconflow.cn/v1/images/generations" `
    -Method POST `
    -Headers @{
        "Authorization" = "Bearer $ApiKey"
        "Content-Type" = "application/json"
    } `
    -Body $body

if ($response.data.Count -eq 0) {
    Write-Error "No image returned"
    exit 1
}

$imageUrl = $response.data[0].url
Write-Host "Downloading..."
$webClient = New-Object System.Net.WebClient
$webClient.Headers.Add("User-Agent", "Mozilla/5.0")
$webClient.DownloadFile($imageUrl, $OutputFile)
$webClient.Dispose()

$size = (Get-Item $OutputFile).Length
Write-Host "Success! Saved to $OutputFile ($([math]::Round($size/1MB,2)) MB)"
